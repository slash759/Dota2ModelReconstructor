namespace FeModelClothGenerator;

public class SphereRigid
{
	public Vector4 Sphere { get; set; }

	public int Node { get; set; }

	public int CollisionMask { get; set; }

	public int VertexMapIndex { get; set; }

	public int Flags { get; set; }
}
