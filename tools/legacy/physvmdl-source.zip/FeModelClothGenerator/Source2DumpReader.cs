using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;

namespace FeModelClothGenerator;

public static class Source2DumpReader
{
	public static FeModelData Load(string file)
	{
		if (!File.Exists(file))
		{
			throw new FileNotFoundException(file);
		}
		string text = File.ReadAllText(file);
		FeModelData feModelData = new FeModelData();
		ParseCtrlNames(text, feModelData);
		ParseVertexMaps(text, feModelData);
		ParseSphereRigids(text, feModelData);
		ParseCapsuleRigids(text, feModelData);
		return feModelData;
	}

	private static void ParseCtrlNames(string text, FeModelData model)
	{
		string text2 = ExtractArray(text, "m_CtrlName");
		if (text2 == null)
		{
			return;
		}
		for (int i = 0; i < text2.Length; i++)
		{
			if (text2[i] == '"')
			{
				int num = text2.IndexOf('"', i + 1);
				if (num > i)
				{
					model.CtrlNames.Add(text2.Substring(i + 1, num - i - 1));
					i = num;
				}
			}
		}
	}

	private static void ParseVertexMaps(string text, FeModelData model)
	{
		string text2 = ExtractArray(text, "m_VertexMaps");
		if (text2 == null)
		{
			return;
		}
		List<string> list = ExtractObjects(text2);
		foreach (string item in list)
		{
			string text3 = ExtractString(item, "sName");
			if (!string.IsNullOrEmpty(text3))
			{
				model.VertexMaps.Add(new VertexMap
				{
					Name = text3
				});
			}
		}
	}

	private static void ParseSphereRigids(string text, FeModelData model)
	{
		string text2 = ExtractArray(text, "m_SphereRigids");
		if (text2 == null)
		{
			return;
		}
		foreach (string item2 in ExtractObjects(text2))
		{
			string text3 = ExtractArrayValue(item2, "vSphere");
			float[] array = ParseNumbers(text3);
			if (array.Length >= 4)
			{
				SphereRigid item = new SphereRigid
				{
					Sphere = new Vector4(array[0], array[1], array[2], array[3]),
					Node = ExtractInt(item2, "nNode"),
					CollisionMask = ExtractInt(item2, "nCollisionMask"),
					VertexMapIndex = ExtractInt(item2, "nVertexMapIndex"),
					Flags = ExtractInt(item2, "nFlags")
				};
				model.SphereRigids.Add(item);
			}
		}
	}

	private static void ParseCapsuleRigids(string text, FeModelData model)
	{
		string text2 = ExtractArray(text, "m_TaperedCapsuleRigids");
		if (text2 == null)
		{
			return;
		}
		List<string> list = ExtractObjects(text2);
		Console.WriteLine("Capsule objects encontrados: " + list.Count);
		foreach (string item2 in ExtractObjects(text2))
		{
			string text3 = ExtractArrayValue(item2, "vSphere");
			if (string.IsNullOrEmpty(text3))
			{
				continue;
			}
			List<string> list2 = ExtractInnerArrays(text3);
			if (list2.Count >= 2)
			{
				float[] array = ParseNumbers(list2[0]);
				float[] array2 = ParseNumbers(list2[1]);
				if (array.Length >= 4 && array2.Length >= 4)
				{
					TaperedCapsuleRigid item = new TaperedCapsuleRigid
					{
						Sphere0 = new Vector4(array[0], array[1], array[2], array[3]),
						Sphere1 = new Vector4(array2[0], array2[1], array2[2], array2[3]),
						Node = ExtractInt(item2, "nNode"),
						CollisionMask = ExtractInt(item2, "nCollisionMask"),
						VertexMapIndex = ExtractInt(item2, "nVertexMapIndex"),
						Flags = ExtractInt(item2, "nFlags")
					};
					model.TaperedCapsuleRigids.Add(item);
				}
			}
		}
	}

	private static string? ExtractArray(string text, string name)
	{
		int num = text.IndexOf(name, StringComparison.Ordinal);
		if (num < 0)
		{
			return null;
		}
		int num2 = text.IndexOf('[', num);
		if (num2 < 0)
		{
			return null;
		}
		return ReadBalanced(text, num2, '[', ']');
	}

	private static string ReadBalanced(string text, int start, char open, char close)
	{
		int num = 0;
		for (int i = start; i < text.Length; i++)
		{
			if (text[i] == open)
			{
				num++;
			}
			if (text[i] == close)
			{
				num--;
			}
			if (num == 0)
			{
				return text.Substring(start, i - start + 1);
			}
		}
		return "";
	}

	private static List<string> ExtractObjects(string block)
	{
		List<string> list = new List<string>();
		int num = 0;
		int num2 = 0;
		int num3 = -1;
		for (int i = 0; i < block.Length; i++)
		{
			char c = block[i];
			switch (c)
			{
			case '[':
				num++;
				break;
			case ']':
				num--;
				break;
			}
			switch (c)
			{
			case '{':
				num2++;
				if (num2 == 1)
				{
					num3 = i;
				}
				break;
			case '}':
				num2--;
				if (num2 == 0 && num3 >= 0)
				{
					list.Add(block.Substring(num3, i - num3 + 1));
					num3 = -1;
				}
				break;
			}
		}
		return list;
	}

	private static List<string> ExtractArrays(string text)
	{
		List<string> list = new List<string>();
		int num = 0;
		int num2 = -1;
		for (int i = 0; i < text.Length; i++)
		{
			if (text[i] == '[')
			{
				if (num == 0)
				{
					num2 = i;
				}
				num++;
			}
			if (text[i] == ']')
			{
				num--;
				if (num == 0 && num2 >= 0)
				{
					list.Add(text.Substring(num2 + 1, i - num2 - 1));
				}
			}
		}
		return list;
	}

	private static List<string> ExtractInnerArrays(string text)
	{
		List<string> list = new List<string>();
		int num = 0;
		int num2 = -1;
		for (int i = 0; i < text.Length; i++)
		{
			if (text[i] == '[')
			{
				num++;
				if (num == 2)
				{
					num2 = i;
				}
			}
			if (text[i] == ']')
			{
				if (num == 2 && num2 >= 0)
				{
					list.Add(text.Substring(num2 + 1, i - num2 - 1));
					num2 = -1;
				}
				num--;
			}
		}
		return list;
	}

	private static string ExtractArrayValue(string text, string name)
	{
		int num = text.IndexOf(name);
		if (num < 0)
		{
			return "";
		}
		int num2 = text.IndexOf('[', num);
		return (num2 < 0) ? "" : ReadBalanced(text, num2, '[', ']');
	}

	private static string ExtractString(string text, string name)
	{
		int num = text.IndexOf(name);
		if (num < 0)
		{
			return "";
		}
		int num2 = text.IndexOf('"', num);
		int num3 = text.IndexOf('"', num2 + 1);
		if (num2 < 0 || num3 < 0)
		{
			return "";
		}
		return text.Substring(num2 + 1, num3 - num2 - 1);
	}

	private static int ExtractInt(string text, string name)
	{
		int num = text.IndexOf(name);
		if (num < 0)
		{
			return 0;
		}
		int num2 = text.IndexOf('=', num);
		if (num2 < 0)
		{
			return 0;
		}
		int i;
		for (i = num2 + 1; i < text.Length && char.IsWhiteSpace(text[i]); i++)
		{
		}
		StringBuilder stringBuilder = new StringBuilder();
		for (; i < text.Length && (char.IsDigit(text[i]) || text[i] == '-'); i++)
		{
			stringBuilder.Append(text[i]);
		}
		int result;
		return int.TryParse(stringBuilder.ToString(), out result) ? result : 0;
	}

	private static float[] ParseNumbers(string text)
	{
		List<float> list = new List<float>();
		string text2 = text.Replace("[", "").Replace("]", "");
		string[] array = text2.Split(',', StringSplitOptions.RemoveEmptyEntries);
		string[] array2 = array;
		foreach (string text3 in array2)
		{
			if (float.TryParse(text3.Trim(), NumberStyles.Float, CultureInfo.InvariantCulture, out var result))
			{
				list.Add(result);
			}
		}
		return list.ToArray();
	}
}
