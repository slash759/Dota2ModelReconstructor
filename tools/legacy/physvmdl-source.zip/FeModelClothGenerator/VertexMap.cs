namespace FeModelClothGenerator;

public class VertexMap
{
	public string Name { get; set; } = "";
}
