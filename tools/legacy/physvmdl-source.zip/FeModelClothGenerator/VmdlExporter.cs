using System.IO;
using System.Text;

namespace FeModelClothGenerator;

public static class VmdlExporter
{
	public static void Write(string file, ClothShapeList cloth)
	{
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.AppendLine("{");
		stringBuilder.AppendLine("    _class = \"ClothShapeList\"");
		stringBuilder.AppendLine("    children = ");
		stringBuilder.AppendLine("    [");
		WriteSpheres(stringBuilder, cloth);
		WriteCapsules(stringBuilder, cloth);
		stringBuilder.AppendLine("    ]");
		stringBuilder.AppendLine("}");
		File.WriteAllText(file, stringBuilder.ToString());
	}

	private static void WriteSpheres(StringBuilder sb, ClothShapeList cloth)
	{
		sb.AppendLine("        {");
		sb.AppendLine("            _class = \"Folder\"");
		sb.AppendLine("            name = \"spheres\"");
		sb.AppendLine("            children = ");
		sb.AppendLine("            [");
		foreach (ClothShapeSphere sphere in cloth.Spheres)
		{
			WriteSphere(sb, sphere);
		}
		sb.AppendLine("            ]");
		sb.AppendLine("        },");
	}

	private static void WriteSphere(StringBuilder sb, ClothShapeSphere sphere)
	{
		sb.AppendLine("                {");
		sb.AppendLine("                    _class = \"ClothShapeSphere\"");
		StringBuilder stringBuilder = sb;
		StringBuilder stringBuilder2 = stringBuilder;
		StringBuilder.AppendInterpolatedStringHandler handler = new StringBuilder.AppendInterpolatedStringHandler(36, 1, stringBuilder);
		handler.AppendLiteral("                    parent_bone = \"");
		handler.AppendFormatted(sphere.ParentBone);
		handler.AppendLiteral("\"");
		stringBuilder2.AppendLine(ref handler);
		WriteLayers(sb, sphere.Layer0, sphere.Layer1, sphere.Layer2, sphere.Layer3);
		stringBuilder = sb;
		StringBuilder stringBuilder3 = stringBuilder;
		handler = new StringBuilder.AppendInterpolatedStringHandler(47, 1, stringBuilder);
		handler.AppendLiteral("                    cloth_collision_priority = ");
		handler.AppendFormatted(sphere.CollisionPriority);
		stringBuilder3.AppendLine(ref handler);
		stringBuilder = sb;
		StringBuilder stringBuilder4 = stringBuilder;
		handler = new StringBuilder.AppendInterpolatedStringHandler(35, 1, stringBuilder);
		handler.AppendLiteral("                    vertex_map = \"");
		handler.AppendFormatted(sphere.VertexMap);
		handler.AppendLiteral("\"");
		stringBuilder4.AppendLine(ref handler);
		sb.AppendLine("                    inverted_collision = false");
		sb.AppendLine("                    planarize = false");
		sb.AppendLine("                    bounciness = 0.0");
		stringBuilder = sb;
		StringBuilder stringBuilder5 = stringBuilder;
		handler = new StringBuilder.AppendInterpolatedStringHandler(29, 1, stringBuilder);
		handler.AppendLiteral("                    radius = ");
		handler.AppendFormatted(sphere.Radius);
		stringBuilder5.AppendLine(ref handler);
		stringBuilder = sb;
		StringBuilder stringBuilder6 = stringBuilder;
		handler = new StringBuilder.AppendInterpolatedStringHandler(37, 3, stringBuilder);
		handler.AppendLiteral("                    center = [ ");
		handler.AppendFormatted(sphere.Center.X);
		handler.AppendLiteral(", ");
		handler.AppendFormatted(sphere.Center.Y);
		handler.AppendLiteral(", ");
		handler.AppendFormatted(sphere.Center.Z);
		handler.AppendLiteral(" ]");
		stringBuilder6.AppendLine(ref handler);
		sb.AppendLine("                },");
	}

	private static void WriteCapsules(StringBuilder sb, ClothShapeList cloth)
	{
		sb.AppendLine("        {");
		sb.AppendLine("            _class = \"Folder\"");
		sb.AppendLine("            name = \"capsules\"");
		sb.AppendLine("            children = ");
		sb.AppendLine("            [");
		foreach (ClothShapeCapsule capsule in cloth.Capsules)
		{
			WriteCapsule(sb, capsule);
		}
		sb.AppendLine("            ]");
		sb.AppendLine("        },");
	}

	private static void WriteCapsule(StringBuilder sb, ClothShapeCapsule capsule)
	{
		sb.AppendLine("                {");
		sb.AppendLine("                    _class = \"ClothShapeCapsule\"");
		StringBuilder stringBuilder = sb;
		StringBuilder stringBuilder2 = stringBuilder;
		StringBuilder.AppendInterpolatedStringHandler handler = new StringBuilder.AppendInterpolatedStringHandler(36, 1, stringBuilder);
		handler.AppendLiteral("                    parent_bone = \"");
		handler.AppendFormatted(capsule.ParentBone);
		handler.AppendLiteral("\"");
		stringBuilder2.AppendLine(ref handler);
		WriteLayers(sb, capsule.Layer0, capsule.Layer1, capsule.Layer2, capsule.Layer3);
		stringBuilder = sb;
		StringBuilder stringBuilder3 = stringBuilder;
		handler = new StringBuilder.AppendInterpolatedStringHandler(47, 1, stringBuilder);
		handler.AppendLiteral("                    cloth_collision_priority = ");
		handler.AppendFormatted(capsule.CollisionPriority);
		stringBuilder3.AppendLine(ref handler);
		stringBuilder = sb;
		StringBuilder stringBuilder4 = stringBuilder;
		handler = new StringBuilder.AppendInterpolatedStringHandler(35, 1, stringBuilder);
		handler.AppendLiteral("                    vertex_map = \"");
		handler.AppendFormatted(capsule.VertexMap);
		handler.AppendLiteral("\"");
		stringBuilder4.AppendLine(ref handler);
		sb.AppendLine("                    inverted_collision = false");
		sb.AppendLine("                    planarize = false");
		sb.AppendLine("                    bounciness = 0.0");
		stringBuilder = sb;
		StringBuilder stringBuilder5 = stringBuilder;
		handler = new StringBuilder.AppendInterpolatedStringHandler(30, 1, stringBuilder);
		handler.AppendLiteral("                    radius0 = ");
		handler.AppendFormatted(capsule.Radius0);
		stringBuilder5.AppendLine(ref handler);
		stringBuilder = sb;
		StringBuilder stringBuilder6 = stringBuilder;
		handler = new StringBuilder.AppendInterpolatedStringHandler(30, 1, stringBuilder);
		handler.AppendLiteral("                    radius1 = ");
		handler.AppendFormatted(capsule.Radius1);
		stringBuilder6.AppendLine(ref handler);
		stringBuilder = sb;
		StringBuilder stringBuilder7 = stringBuilder;
		handler = new StringBuilder.AppendInterpolatedStringHandler(37, 3, stringBuilder);
		handler.AppendLiteral("                    point0 = [ ");
		handler.AppendFormatted(capsule.Point0.X);
		handler.AppendLiteral(", ");
		handler.AppendFormatted(capsule.Point0.Y);
		handler.AppendLiteral(", ");
		handler.AppendFormatted(capsule.Point0.Z);
		handler.AppendLiteral(" ]");
		stringBuilder7.AppendLine(ref handler);
		stringBuilder = sb;
		StringBuilder stringBuilder8 = stringBuilder;
		handler = new StringBuilder.AppendInterpolatedStringHandler(37, 3, stringBuilder);
		handler.AppendLiteral("                    point1 = [ ");
		handler.AppendFormatted(capsule.Point1.X);
		handler.AppendLiteral(", ");
		handler.AppendFormatted(capsule.Point1.Y);
		handler.AppendLiteral(", ");
		handler.AppendFormatted(capsule.Point1.Z);
		handler.AppendLiteral(" ]");
		stringBuilder8.AppendLine(ref handler);
		sb.AppendLine("                },");
	}

	private static void WriteLayers(StringBuilder sb, bool l0, bool l1, bool l2, bool l3)
	{
		StringBuilder stringBuilder = sb;
		StringBuilder stringBuilder2 = stringBuilder;
		StringBuilder.AppendInterpolatedStringHandler handler = new StringBuilder.AppendInterpolatedStringHandler(45, 1, stringBuilder);
		handler.AppendLiteral("                    cloth_collision_layer0 = ");
		handler.AppendFormatted(l0.ToString().ToLower());
		stringBuilder2.AppendLine(ref handler);
		stringBuilder = sb;
		StringBuilder stringBuilder3 = stringBuilder;
		handler = new StringBuilder.AppendInterpolatedStringHandler(45, 1, stringBuilder);
		handler.AppendLiteral("                    cloth_collision_layer1 = ");
		handler.AppendFormatted(l1.ToString().ToLower());
		stringBuilder3.AppendLine(ref handler);
		stringBuilder = sb;
		StringBuilder stringBuilder4 = stringBuilder;
		handler = new StringBuilder.AppendInterpolatedStringHandler(45, 1, stringBuilder);
		handler.AppendLiteral("                    cloth_collision_layer2 = ");
		handler.AppendFormatted(l2.ToString().ToLower());
		stringBuilder4.AppendLine(ref handler);
		stringBuilder = sb;
		StringBuilder stringBuilder5 = stringBuilder;
		handler = new StringBuilder.AppendInterpolatedStringHandler(45, 1, stringBuilder);
		handler.AppendLiteral("                    cloth_collision_layer3 = ");
		handler.AppendFormatted(l3.ToString().ToLower());
		stringBuilder5.AppendLine(ref handler);
	}
}
