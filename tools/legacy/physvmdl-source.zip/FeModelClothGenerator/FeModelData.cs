using System.Collections.Generic;

namespace FeModelClothGenerator;

public class FeModelData
{
	public List<string> CtrlNames { get; set; } = new List<string>();

	public List<VertexMap> VertexMaps { get; set; } = new List<VertexMap>();

	public List<SphereRigid> SphereRigids { get; set; } = new List<SphereRigid>();

	public List<TaperedCapsuleRigid> TaperedCapsuleRigids { get; set; } = new List<TaperedCapsuleRigid>();
}
