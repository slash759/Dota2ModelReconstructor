using System.Collections.Generic;

namespace FeModelClothGenerator;

public class ClothShapeList
{
	public List<ClothShapeSphere> Spheres { get; set; } = new List<ClothShapeSphere>();

	public List<ClothShapeCapsule> Capsules { get; set; } = new List<ClothShapeCapsule>();
}
