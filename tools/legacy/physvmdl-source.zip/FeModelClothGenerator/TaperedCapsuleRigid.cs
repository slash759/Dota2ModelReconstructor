namespace FeModelClothGenerator;

public class TaperedCapsuleRigid
{
	public Vector4 Sphere0 { get; set; }

	public Vector4 Sphere1 { get; set; }

	public int Node { get; set; }

	public int CollisionMask { get; set; }

	public int VertexMapIndex { get; set; }

	public int Flags { get; set; }
}
