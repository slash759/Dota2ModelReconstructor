using System;

namespace FeModelClothGenerator;

internal class Program
{
	private static void Main(string[] args)
	{
		Console.WriteLine("=== Source 2 Cloth Collision Generator ===");
		try
		{
			string file = "phys.txt";
			string text = "cloth_shapes.vmdl.txt";
			Console.WriteLine();
			Console.WriteLine("[1] Leyendo dump Source 2...");
			FeModelData feModelData = Source2DumpReader.Load(file);
			Console.WriteLine($"CtrlNames: {feModelData.CtrlNames.Count}");
			Console.WriteLine($"VertexMaps: {feModelData.VertexMaps.Count}");
			Console.WriteLine($"Spheres: {feModelData.SphereRigids.Count}");
			Console.WriteLine($"Capsules: {feModelData.TaperedCapsuleRigids.Count}");
			Console.WriteLine();
			Console.WriteLine("[2] Generando ClothShapeList...");
			ClothShapeList clothShapeList = ClothCollisionGenerator.Generate(feModelData);
			Console.WriteLine($"Generated spheres: {clothShapeList.Spheres.Count}");
			Console.WriteLine($"Generated capsules: {clothShapeList.Capsules.Count}");
			Console.WriteLine();
			Console.WriteLine("[3] Exportando VMDL...");
			VmdlExporter.Write(text, clothShapeList);
			Console.WriteLine();
			Console.WriteLine("Proceso terminado.");
			Console.WriteLine("Archivo creado: " + text);
		}
		catch (Exception ex)
		{
			Console.WriteLine();
			Console.WriteLine("ERROR:");
			Console.WriteLine(ex.Message);
			Console.WriteLine();
			Console.WriteLine(ex.StackTrace);
		}
		Console.WriteLine();
		Console.WriteLine("Presiona una tecla para salir...");
		Console.ReadKey();
	}
}
