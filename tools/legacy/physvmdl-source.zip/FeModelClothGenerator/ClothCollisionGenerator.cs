namespace FeModelClothGenerator;

public static class ClothCollisionGenerator
{
	public static ClothShapeList Generate(FeModelData model)
	{
		ClothShapeList result = new ClothShapeList();
		GenerateSpheres(model, result);
		GenerateCapsules(model, result);
		return result;
	}

	private static void GenerateSpheres(FeModelData model, ClothShapeList result)
	{
		foreach (SphereRigid sphereRigid in model.SphereRigids)
		{
			ClothShapeSphere clothShapeSphere = new ClothShapeSphere();
			clothShapeSphere.ParentBone = GetBoneName(model, sphereRigid.Node);
			SetLayers(sphereRigid.CollisionMask, clothShapeSphere);
			clothShapeSphere.CollisionPriority = 0;
			clothShapeSphere.VertexMap = GetVertexMapName(model, sphereRigid.VertexMapIndex);
			clothShapeSphere.InvertedCollision = false;
			clothShapeSphere.Planarize = false;
			clothShapeSphere.Bounciness = 0f;
			clothShapeSphere.Center = new Vector3(sphereRigid.Sphere.X, sphereRigid.Sphere.Y, sphereRigid.Sphere.Z);
			clothShapeSphere.Radius = sphereRigid.Sphere.W;
			result.Spheres.Add(clothShapeSphere);
		}
	}

	private static void GenerateCapsules(FeModelData model, ClothShapeList result)
	{
		foreach (TaperedCapsuleRigid taperedCapsuleRigid in model.TaperedCapsuleRigids)
		{
			ClothShapeCapsule clothShapeCapsule = new ClothShapeCapsule();
			clothShapeCapsule.ParentBone = GetBoneName(model, taperedCapsuleRigid.Node);
			SetLayers(taperedCapsuleRigid.CollisionMask, clothShapeCapsule);
			clothShapeCapsule.CollisionPriority = 0;
			clothShapeCapsule.VertexMap = GetVertexMapName(model, taperedCapsuleRigid.VertexMapIndex);
			clothShapeCapsule.InvertedCollision = false;
			clothShapeCapsule.Planarize = false;
			clothShapeCapsule.Bounciness = 0f;
			clothShapeCapsule.Point0 = new Vector3(taperedCapsuleRigid.Sphere0.X, taperedCapsuleRigid.Sphere0.Y, taperedCapsuleRigid.Sphere0.Z);
			clothShapeCapsule.Radius0 = taperedCapsuleRigid.Sphere0.W;
			clothShapeCapsule.Point1 = new Vector3(taperedCapsuleRigid.Sphere1.X, taperedCapsuleRigid.Sphere1.Y, taperedCapsuleRigid.Sphere1.Z);
			clothShapeCapsule.Radius1 = taperedCapsuleRigid.Sphere1.W;
			result.Capsules.Add(clothShapeCapsule);
		}
	}

	private static string GetBoneName(FeModelData model, int index)
	{
		if (index < 0 || index >= model.CtrlNames.Count)
		{
			return "";
		}
		return model.CtrlNames[index];
	}

	private static string GetVertexMapName(FeModelData model, int index)
	{
		if (index == 65535)
		{
			return "";
		}
		if (index < 0 || index >= model.VertexMaps.Count)
		{
			return "";
		}
		return model.VertexMaps[index].Name;
	}

	private static void SetLayers(int mask, ClothShapeSphere sphere)
	{
		sphere.Layer0 = (mask & 1) != 0;
		sphere.Layer1 = (mask & 2) != 0;
		sphere.Layer2 = (mask & 4) != 0;
		sphere.Layer3 = (mask & 8) != 0;
	}

	private static void SetLayers(int mask, ClothShapeCapsule capsule)
	{
		capsule.Layer0 = (mask & 1) != 0;
		capsule.Layer1 = (mask & 2) != 0;
		capsule.Layer2 = (mask & 4) != 0;
		capsule.Layer3 = (mask & 8) != 0;
	}
}
