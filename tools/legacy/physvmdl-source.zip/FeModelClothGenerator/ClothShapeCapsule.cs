namespace FeModelClothGenerator;

public class ClothShapeCapsule
{
	public string ParentBone { get; set; } = "";

	public bool Layer0 { get; set; }

	public bool Layer1 { get; set; }

	public bool Layer2 { get; set; }

	public bool Layer3 { get; set; }

	public int CollisionPriority { get; set; } = 0;

	public string VertexMap { get; set; } = "";

	public bool InvertedCollision { get; set; } = false;

	public bool Planarize { get; set; } = false;

	public float Bounciness { get; set; } = 0f;

	public float Radius0 { get; set; }

	public float Radius1 { get; set; }

	public Vector3 Point0 { get; set; }

	public Vector3 Point1 { get; set; }
}
