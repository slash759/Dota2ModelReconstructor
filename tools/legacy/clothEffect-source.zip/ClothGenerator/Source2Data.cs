using System.Collections.Generic;

namespace ClothGenerator;

public class Source2Data
{
	public List<VertexMapData> VertexMaps { get; set; } = new List<VertexMapData>();

	public List<EffectData> Effects { get; set; } = new List<EffectData>();
}
