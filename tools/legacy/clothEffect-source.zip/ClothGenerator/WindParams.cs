using System.Collections.Generic;
using System.Numerics;

namespace ClothGenerator;

public class WindParams
{
	public Vector3 Strength;

	public float AirToCloth;

	public float LocalSpace;

	public float Choppiness;

	public int VertexMapHash;

	public List<VortexData> Vortices = new List<VortexData>();
}
