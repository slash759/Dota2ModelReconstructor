using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;

namespace ClothGenerator;

public class ClothEffectGenerator
{
	public ClothEffectList Generate(Source2Data data)
	{
		ClothEffectList clothEffectList = new ClothEffectList();
		foreach (EffectData effect in data.Effects)
		{
			if (effect.Type == 1)
			{
				ClothEffectWind clothEffectWind = GenerateWind(effect, data.VertexMaps);
				if (clothEffectWind != null)
				{
					clothEffectList.Winds.Add(clothEffectWind);
				}
			}
			else if (effect.Type == 3)
			{
				ClothEffectStiffen clothEffectStiffen = GenerateStiffen(effect, data.VertexMaps);
				if (clothEffectStiffen != null)
				{
					clothEffectList.Stiffens.Add(clothEffectStiffen);
				}
			}
		}
		return clothEffectList;
	}

	private ClothEffectWind GenerateWind(EffectData effect, List<VertexMapData> maps)
	{
		if (effect.Wind == null)
		{
			return null;
		}
		ClothEffectWind clothEffectWind = new ClothEffectWind();
		clothEffectWind.Name = effect.Name;
		clothEffectWind.VertexMap = ResolveVertexMap(effect.Wind.VertexMapHash, maps);
		Vector3 angles = CalculateAngles(effect.Wind.Strength);
		clothEffectWind.Angles = angles;
		clothEffectWind.WindSpeedMph = CalculateWindSpeed(effect.Wind.Strength);
		if (effect.Wind.AirToCloth > 0f)
		{
			clothEffectWind.ClothAirDensity = 1f / effect.Wind.AirToCloth;
		}
		else
		{
			clothEffectWind.ClothAirDensity = 1f;
		}
		clothEffectWind.LocalSpace = effect.Wind.LocalSpace;
		clothEffectWind.VortexCount = effect.Wind.Vortices.Count;
		if (effect.Wind.Vortices.Count > 0)
		{
			VortexData vortexData = effect.Wind.Vortices[0];
			clothEffectWind.VortexMaxSpeedMph = vortexData.MaxSpeed / 17.6f;
			clothEffectWind.VortexCellSize = vortexData.MaxCell;
		}
		clothEffectWind.VortexChoppiness = effect.Wind.Choppiness;
		return clothEffectWind;
	}

	private ClothEffectStiffen GenerateStiffen(EffectData effect, List<VertexMapData> maps)
	{
		if (effect.Stiffen == null)
		{
			return null;
		}
		ClothEffectStiffen clothEffectStiffen = new ClothEffectStiffen();
		clothEffectStiffen.Name = effect.Name;
		clothEffectStiffen.VertexMap = ResolveVertexMap(effect.Stiffen.VertexMapHash, maps);
		clothEffectStiffen.Stiffness = effect.Stiffen.Stiffness;
		clothEffectStiffen.BoneOverlay = effect.Stiffen.BoneOverlay;
		return clothEffectStiffen;
	}

	private string ResolveVertexMap(int hash, List<VertexMapData> maps)
	{
		uint unsignedHash = (uint)hash;
		VertexMapData vertexMapData = maps.FirstOrDefault((VertexMapData x) => x.NameHash == unsignedHash);
		if (vertexMapData == null)
		{
			return "";
		}
		return vertexMapData.Name;
	}

	private float CalculateWindSpeed(Vector3 strength)
	{
		float num = strength.Length();
		return num / 17.6f;
	}

	private Vector3 CalculateAngles(Vector3 strength)
	{
		float num = strength.Length();
		if (num < 0.0001f)
		{
			return Vector3.Zero;
		}
		Vector3 vector = strength / num;
		float num2 = 0f - (float)Math.Asin(vector.Z);
		float num3 = (float)Math.Atan2(vector.Y, vector.X);
		float z = 0f;
		return new Vector3(num2 * 180f / (float)Math.PI, num3 * 180f / (float)Math.PI, z);
	}
}
