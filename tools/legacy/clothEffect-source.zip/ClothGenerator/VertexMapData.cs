namespace ClothGenerator;

public class VertexMapData
{
	public string Name { get; set; }

	public uint NameHash { get; set; }
}
