namespace ClothGenerator;

public class StiffenParams
{
	public float Stiffness;

	public float BoneOverlay;

	public int VertexMapHash;
}
