using System.Collections.Generic;

namespace ClothGenerator;

public class ClothEffectList
{
	public List<ClothEffectWind> Winds = new List<ClothEffectWind>();

	public List<ClothEffectStiffen> Stiffens = new List<ClothEffectStiffen>();
}
