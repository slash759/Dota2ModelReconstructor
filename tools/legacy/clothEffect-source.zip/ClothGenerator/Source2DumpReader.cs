using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Numerics;
using System.Text.RegularExpressions;

namespace ClothGenerator;

public class Source2DumpReader
{
	public Source2Data Read(string file)
	{
		if (!File.Exists(file))
		{
			throw new FileNotFoundException(file);
		}
		string text = File.ReadAllText(file);
		Source2Data source2Data = new Source2Data();
		ParseVertexMaps(text, source2Data);
		ParseEffects(text, source2Data);
		return source2Data;
	}

	private void ParseVertexMaps(string text, Source2Data data)
	{
		string text2 = ExtractArray(text, "m_VertexMaps");
		if (text2 == null)
		{
			return;
		}
		foreach (string item in ExtractObjects(text2))
		{
			VertexMapData vertexMapData = new VertexMapData();
			vertexMapData.Name = GetString(item, "sName");
			vertexMapData.NameHash = GetUInt(item, "nNameHash");
			if (!string.IsNullOrEmpty(vertexMapData.Name))
			{
				data.VertexMaps.Add(vertexMapData);
			}
		}
	}

	private void ParseEffects(string text, Source2Data data)
	{
		string text2 = ExtractArray(text, "m_Effects");
		if (text2 == null)
		{
			return;
		}
		foreach (string item in ExtractObjects(text2))
		{
			EffectData effectData = new EffectData();
			effectData.Name = GetString(item, "sName");
			effectData.NameHash = GetUInt(item, "nNameHash");
			effectData.Type = GetInt(item, "nType");
			string text3 = ExtractObject(item, "m_Params");
			if (effectData.Type == 1)
			{
				effectData.Wind = ParseWind(text3);
			}
			else if (effectData.Type == 3)
			{
				effectData.Stiffen = ParseStiffen(text3);
			}
			data.Effects.Add(effectData);
		}
	}

	private WindParams ParseWind(string text)
	{
		WindParams windParams = new WindParams();
		windParams.Strength = GetVector3(text, "Strength");
		windParams.AirToCloth = GetFloat(text, "AirToCloth");
		windParams.LocalSpace = GetFloat(text, "LocalSpace");
		windParams.Choppiness = GetFloat(text, "Choppiness");
		windParams.VertexMapHash = GetInt(text, "VertexMap");
		string text2 = ExtractArray(text, "Vortices");
		if (text2 != null)
		{
			foreach (string item in ExtractObjects(text2))
			{
				VortexData vortexData = new VortexData();
				vortexData.MaxSpeed = GetFloat(item, "MaxSpeed");
				vortexData.MaxCell = GetFloat(item, "MaxCell");
				windParams.Vortices.Add(vortexData);
			}
		}
		return windParams;
	}

	private StiffenParams ParseStiffen(string text)
	{
		StiffenParams stiffenParams = new StiffenParams();
		stiffenParams.Stiffness = GetFloat(text, "Stiffness");
		stiffenParams.BoneOverlay = GetFloat(text, "BoneOverlay");
		stiffenParams.VertexMapHash = GetInt(text, "VertexMap");
		return stiffenParams;
	}

	private string ExtractArray(string text, string name)
	{
		int num = text.IndexOf(name, StringComparison.Ordinal);
		if (num < 0)
		{
			return null;
		}
		int num2 = text.IndexOf('[', num);
		if (num2 < 0)
		{
			return null;
		}
		int num3 = FindClosing(text, num2, '[', ']');
		if (num3 < 0)
		{
			return null;
		}
		return text.Substring(num2 + 1, num3 - num2 - 1);
	}

	private string ExtractObject(string text, string name)
	{
		int num = text.IndexOf(name, StringComparison.Ordinal);
		if (num < 0)
		{
			return "";
		}
		int num2 = text.IndexOf('{', num);
		if (num2 < 0)
		{
			return "";
		}
		int num3 = FindClosing(text, num2, '{', '}');
		if (num3 < 0)
		{
			return "";
		}
		return text.Substring(num2 + 1, num3 - num2 - 1);
	}

	private List<string> ExtractObjects(string block)
	{
		List<string> list = new List<string>();
		int num = 0;
		int num2 = -1;
		for (int i = 0; i < block.Length; i++)
		{
			switch (block[i])
			{
			case '{':
				if (num == 0)
				{
					num2 = i;
				}
				num++;
				break;
			case '}':
				num--;
				if (num == 0 && num2 >= 0)
				{
					list.Add(block.Substring(num2 + 1, i - num2 - 1));
					num2 = -1;
				}
				break;
			}
		}
		return list;
	}

	private int FindClosing(string text, int start, char open, char close)
	{
		int num = 0;
		for (int i = start; i < text.Length; i++)
		{
			if (text[i] == open)
			{
				num++;
			}
			else if (text[i] == close)
			{
				num--;
				if (num == 0)
				{
					return i;
				}
			}
		}
		return -1;
	}

	private string GetString(string text, string key)
	{
		Match match = Regex.Match(text, key + "\\s*=\\s*\"([^\"]+)\"");
		return match.Success ? match.Groups[1].Value : "";
	}

	private int GetInt(string text, string key)
	{
		Match match = Regex.Match(text, key + "\\s*=\\s*(-?\\d+)");
		return match.Success ? int.Parse(match.Groups[1].Value, CultureInfo.InvariantCulture) : 0;
	}

	private uint GetUInt(string text, string key)
	{
		Match match = Regex.Match(text, key + "\\s*=\\s*(\\d+)");
		return match.Success ? uint.Parse(match.Groups[1].Value, CultureInfo.InvariantCulture) : 0u;
	}

	private float GetFloat(string text, string key)
	{
		Match match = Regex.Match(text, key + "\\s*=\\s*(-?[\\d\\.]+)");
		return match.Success ? float.Parse(match.Groups[1].Value, CultureInfo.InvariantCulture) : 0f;
	}

	private Vector3 GetVector3(string text, string key)
	{
		Match match = Regex.Match(text, key + "\\s*=\\s*\\[\\s*(-?[\\d\\.]+),\\s*(-?[\\d\\.]+),\\s*(-?[\\d\\.]+)\\s*\\]");
		if (!match.Success)
		{
			return Vector3.Zero;
		}
		return new Vector3(float.Parse(match.Groups[1].Value, CultureInfo.InvariantCulture), float.Parse(match.Groups[2].Value, CultureInfo.InvariantCulture), float.Parse(match.Groups[3].Value, CultureInfo.InvariantCulture));
	}
}
