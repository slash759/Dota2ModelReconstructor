using System.Globalization;
using System.IO;
using System.Text;

namespace ClothGenerator;

public class VmdlExporter
{
	public void Export(ClothEffectList effects, string output)
	{
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.AppendLine("{");
		stringBuilder.AppendLine("\t_class = \"Folder\"");
		stringBuilder.AppendLine("\tname = \"clothEffects\"");
		stringBuilder.AppendLine("\tchildren = ");
		stringBuilder.AppendLine("\t[");
		foreach (ClothEffectWind wind in effects.Winds)
		{
			WriteWind(stringBuilder, wind, 2);
		}
		foreach (ClothEffectStiffen stiffen in effects.Stiffens)
		{
			WriteStiffen(stringBuilder, stiffen, 2);
		}
		stringBuilder.AppendLine("\t]");
		stringBuilder.AppendLine("}");
		File.WriteAllText(output, stringBuilder.ToString());
	}

	private void WriteWind(StringBuilder sb, ClothEffectWind wind, int indent)
	{
		string value = new string('\t', indent);
		StringBuilder stringBuilder = sb;
		StringBuilder stringBuilder2 = stringBuilder;
		StringBuilder.AppendInterpolatedStringHandler handler = new StringBuilder.AppendInterpolatedStringHandler(1, 1, stringBuilder);
		handler.AppendFormatted(value);
		handler.AppendLiteral("{");
		stringBuilder2.AppendLine(ref handler);
		stringBuilder = sb;
		StringBuilder stringBuilder3 = stringBuilder;
		handler = new StringBuilder.AppendInterpolatedStringHandler(27, 1, stringBuilder);
		handler.AppendFormatted(value);
		handler.AppendLiteral("\t_class = \"ClothEffectWind\"");
		stringBuilder3.AppendLine(ref handler);
		stringBuilder = sb;
		StringBuilder stringBuilder4 = stringBuilder;
		handler = new StringBuilder.AppendInterpolatedStringHandler(10, 2, stringBuilder);
		handler.AppendFormatted(value);
		handler.AppendLiteral("\tname = \"");
		handler.AppendFormatted(wind.Name);
		handler.AppendLiteral("\"");
		stringBuilder4.AppendLine(ref handler);
		stringBuilder = sb;
		StringBuilder stringBuilder5 = stringBuilder;
		handler = new StringBuilder.AppendInterpolatedStringHandler(27, 1, stringBuilder);
		handler.AppendFormatted(value);
		handler.AppendLiteral("\torigin = [ 0.0, 0.0, 0.0 ]");
		stringBuilder5.AppendLine(ref handler);
		stringBuilder = sb;
		StringBuilder stringBuilder6 = stringBuilder;
		handler = new StringBuilder.AppendInterpolatedStringHandler(18, 4, stringBuilder);
		handler.AppendFormatted(value);
		handler.AppendLiteral("\tangles = [ ");
		handler.AppendFormatted(wind.Angles.X, "F6");
		handler.AppendLiteral(", ");
		handler.AppendFormatted(wind.Angles.Y, "F6");
		handler.AppendLiteral(", ");
		handler.AppendFormatted(wind.Angles.Z, "F6");
		handler.AppendLiteral(" ]");
		stringBuilder6.AppendLine(ref handler);
		stringBuilder = sb;
		StringBuilder stringBuilder7 = stringBuilder;
		handler = new StringBuilder.AppendInterpolatedStringHandler(16, 2, stringBuilder);
		handler.AppendFormatted(value);
		handler.AppendLiteral("\tvertex_map = \"");
		handler.AppendFormatted(wind.VertexMap);
		handler.AppendLiteral("\"");
		stringBuilder7.AppendLine(ref handler);
		stringBuilder = sb;
		StringBuilder stringBuilder8 = stringBuilder;
		handler = new StringBuilder.AppendInterpolatedStringHandler(25, 1, stringBuilder);
		handler.AppendFormatted(value);
		handler.AppendLiteral("\tcloth_effect_version = 0");
		stringBuilder8.AppendLine(ref handler);
		stringBuilder = sb;
		StringBuilder stringBuilder9 = stringBuilder;
		handler = new StringBuilder.AppendInterpolatedStringHandler(18, 1, stringBuilder);
		handler.AppendFormatted(value);
		handler.AppendLiteral("\tis_global = false");
		stringBuilder9.AppendLine(ref handler);
		stringBuilder = sb;
		StringBuilder stringBuilder10 = stringBuilder;
		handler = new StringBuilder.AppendInterpolatedStringHandler(20, 1, stringBuilder);
		handler.AppendFormatted(value);
		handler.AppendLiteral("\tis_env_wind = false");
		stringBuilder10.AppendLine(ref handler);
		stringBuilder = sb;
		StringBuilder stringBuilder11 = stringBuilder;
		handler = new StringBuilder.AppendInterpolatedStringHandler(18, 2, stringBuilder);
		handler.AppendFormatted(value);
		handler.AppendLiteral("\twind_speed_mph = ");
		handler.AppendFormatted(Format(wind.WindSpeedMph));
		stringBuilder11.AppendLine(ref handler);
		stringBuilder = sb;
		StringBuilder stringBuilder12 = stringBuilder;
		handler = new StringBuilder.AppendInterpolatedStringHandler(15, 2, stringBuilder);
		handler.AppendFormatted(value);
		handler.AppendLiteral("\tlocal_space = ");
		handler.AppendFormatted(Format(wind.LocalSpace));
		stringBuilder12.AppendLine(ref handler);
		stringBuilder = sb;
		StringBuilder stringBuilder13 = stringBuilder;
		handler = new StringBuilder.AppendInterpolatedStringHandler(21, 2, stringBuilder);
		handler.AppendFormatted(value);
		handler.AppendLiteral("\tcloth_air_density = ");
		handler.AppendFormatted(Format(wind.ClothAirDensity));
		stringBuilder13.AppendLine(ref handler);
		stringBuilder = sb;
		StringBuilder stringBuilder14 = stringBuilder;
		handler = new StringBuilder.AppendInterpolatedStringHandler(16, 2, stringBuilder);
		handler.AppendFormatted(value);
		handler.AppendLiteral("\tvortex_count = ");
		handler.AppendFormatted(wind.VortexCount);
		stringBuilder14.AppendLine(ref handler);
		if (wind.VortexCount > 0)
		{
			stringBuilder = sb;
			StringBuilder stringBuilder15 = stringBuilder;
			handler = new StringBuilder.AppendInterpolatedStringHandler(24, 2, stringBuilder);
			handler.AppendFormatted(value);
			handler.AppendLiteral("\tvortex_max_speed_mph = ");
			handler.AppendFormatted(Format(wind.VortexMaxSpeedMph));
			stringBuilder15.AppendLine(ref handler);
			stringBuilder = sb;
			StringBuilder stringBuilder16 = stringBuilder;
			handler = new StringBuilder.AppendInterpolatedStringHandler(20, 2, stringBuilder);
			handler.AppendFormatted(value);
			handler.AppendLiteral("\tvortex_cell_size = ");
			handler.AppendFormatted(Format(wind.VortexCellSize));
			stringBuilder16.AppendLine(ref handler);
			stringBuilder = sb;
			StringBuilder stringBuilder17 = stringBuilder;
			handler = new StringBuilder.AppendInterpolatedStringHandler(21, 2, stringBuilder);
			handler.AppendFormatted(value);
			handler.AppendLiteral("\tvortex_choppiness = ");
			handler.AppendFormatted(Format(wind.VortexChoppiness));
			stringBuilder17.AppendLine(ref handler);
		}
		else
		{
			stringBuilder = sb;
			StringBuilder stringBuilder18 = stringBuilder;
			handler = new StringBuilder.AppendInterpolatedStringHandler(27, 1, stringBuilder);
			handler.AppendFormatted(value);
			handler.AppendLiteral("\tvortex_max_speed_mph = 0.0");
			stringBuilder18.AppendLine(ref handler);
			stringBuilder = sb;
			StringBuilder stringBuilder19 = stringBuilder;
			handler = new StringBuilder.AppendInterpolatedStringHandler(23, 1, stringBuilder);
			handler.AppendFormatted(value);
			handler.AppendLiteral("\tvortex_cell_size = 0.0");
			stringBuilder19.AppendLine(ref handler);
			stringBuilder = sb;
			StringBuilder stringBuilder20 = stringBuilder;
			handler = new StringBuilder.AppendInterpolatedStringHandler(21, 2, stringBuilder);
			handler.AppendFormatted(value);
			handler.AppendLiteral("\tvortex_choppiness = ");
			handler.AppendFormatted(Format(wind.VortexChoppiness));
			stringBuilder20.AppendLine(ref handler);
		}
		stringBuilder = sb;
		StringBuilder stringBuilder21 = stringBuilder;
		handler = new StringBuilder.AppendInterpolatedStringHandler(22, 1, stringBuilder);
		handler.AppendFormatted(value);
		handler.AppendLiteral("\ttime_multiplier = 1.0");
		stringBuilder21.AppendLine(ref handler);
		stringBuilder = sb;
		StringBuilder stringBuilder22 = stringBuilder;
		handler = new StringBuilder.AppendInterpolatedStringHandler(19, 1, stringBuilder);
		handler.AppendFormatted(value);
		handler.AppendLiteral("\tunderwater = false");
		stringBuilder22.AppendLine(ref handler);
		stringBuilder = sb;
		StringBuilder stringBuilder23 = stringBuilder;
		handler = new StringBuilder.AppendInterpolatedStringHandler(2, 1, stringBuilder);
		handler.AppendFormatted(value);
		handler.AppendLiteral("},");
		stringBuilder23.AppendLine(ref handler);
	}

	private void WriteStiffen(StringBuilder sb, ClothEffectStiffen stiff, int indent)
	{
		string value = new string('\t', indent);
		StringBuilder stringBuilder = sb;
		StringBuilder stringBuilder2 = stringBuilder;
		StringBuilder.AppendInterpolatedStringHandler handler = new StringBuilder.AppendInterpolatedStringHandler(1, 1, stringBuilder);
		handler.AppendFormatted(value);
		handler.AppendLiteral("{");
		stringBuilder2.AppendLine(ref handler);
		stringBuilder = sb;
		StringBuilder stringBuilder3 = stringBuilder;
		handler = new StringBuilder.AppendInterpolatedStringHandler(30, 1, stringBuilder);
		handler.AppendFormatted(value);
		handler.AppendLiteral("\t_class = \"ClothEffectStiffen\"");
		stringBuilder3.AppendLine(ref handler);
		stringBuilder = sb;
		StringBuilder stringBuilder4 = stringBuilder;
		handler = new StringBuilder.AppendInterpolatedStringHandler(10, 2, stringBuilder);
		handler.AppendFormatted(value);
		handler.AppendLiteral("\tname = \"");
		handler.AppendFormatted(stiff.Name);
		handler.AppendLiteral("\"");
		stringBuilder4.AppendLine(ref handler);
		stringBuilder = sb;
		StringBuilder stringBuilder5 = stringBuilder;
		handler = new StringBuilder.AppendInterpolatedStringHandler(27, 1, stringBuilder);
		handler.AppendFormatted(value);
		handler.AppendLiteral("\torigin = [ 0.0, 0.0, 0.0 ]");
		stringBuilder5.AppendLine(ref handler);
		stringBuilder = sb;
		StringBuilder stringBuilder6 = stringBuilder;
		handler = new StringBuilder.AppendInterpolatedStringHandler(27, 1, stringBuilder);
		handler.AppendFormatted(value);
		handler.AppendLiteral("\tangles = [ 0.0, 0.0, 0.0 ]");
		stringBuilder6.AppendLine(ref handler);
		stringBuilder = sb;
		StringBuilder stringBuilder7 = stringBuilder;
		handler = new StringBuilder.AppendInterpolatedStringHandler(16, 2, stringBuilder);
		handler.AppendFormatted(value);
		handler.AppendLiteral("\tvertex_map = \"");
		handler.AppendFormatted(stiff.VertexMap);
		handler.AppendLiteral("\"");
		stringBuilder7.AppendLine(ref handler);
		stringBuilder = sb;
		StringBuilder stringBuilder8 = stringBuilder;
		handler = new StringBuilder.AppendInterpolatedStringHandler(25, 1, stringBuilder);
		handler.AppendFormatted(value);
		handler.AppendLiteral("\tcloth_effect_version = 0");
		stringBuilder8.AppendLine(ref handler);
		stringBuilder = sb;
		StringBuilder stringBuilder9 = stringBuilder;
		handler = new StringBuilder.AppendInterpolatedStringHandler(13, 2, stringBuilder);
		handler.AppendFormatted(value);
		handler.AppendLiteral("\tStiffness = ");
		handler.AppendFormatted(Format(stiff.Stiffness));
		stringBuilder9.AppendLine(ref handler);
		stringBuilder = sb;
		StringBuilder stringBuilder10 = stringBuilder;
		handler = new StringBuilder.AppendInterpolatedStringHandler(15, 2, stringBuilder);
		handler.AppendFormatted(value);
		handler.AppendLiteral("\tBoneOverlay = ");
		handler.AppendFormatted(Format(stiff.BoneOverlay));
		stringBuilder10.AppendLine(ref handler);
		stringBuilder = sb;
		StringBuilder stringBuilder11 = stringBuilder;
		handler = new StringBuilder.AppendInterpolatedStringHandler(2, 1, stringBuilder);
		handler.AppendFormatted(value);
		handler.AppendLiteral("},");
		stringBuilder11.AppendLine(ref handler);
	}

	private string Format(float value)
	{
		return value.ToString("0.######", CultureInfo.InvariantCulture);
	}
}
