using System.Numerics;

namespace ClothGenerator;

public class ClothEffectWind
{
	public string Name;

	public string VertexMap;

	public Vector3 Angles;

	public float WindSpeedMph;

	public float LocalSpace;

	public float ClothAirDensity;

	public int VortexCount;

	public float VortexMaxSpeedMph;

	public float VortexCellSize;

	public float VortexChoppiness;
}
