namespace ClothGenerator;

public class VortexData
{
	public float MaxSpeed;

	public float MaxCell;
}
