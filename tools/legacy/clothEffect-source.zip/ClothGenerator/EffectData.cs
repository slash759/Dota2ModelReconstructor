namespace ClothGenerator;

public class EffectData
{
	public string Name { get; set; }

	public uint NameHash { get; set; }

	public int Type { get; set; }

	public WindParams Wind { get; set; }

	public StiffenParams Stiffen { get; set; }
}
