namespace ClothGenerator;

public class ClothEffectStiffen
{
	public string Name;

	public string VertexMap;

	public float Stiffness;

	public float BoneOverlay;
}
