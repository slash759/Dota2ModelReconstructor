using System;

namespace ClothGenerator;

internal class Program
{
	private static void Main(string[] args)
	{
		Console.WriteLine("=== Source 2 Cloth Effects Generator ===\n");
		string file = "phys.txt";
		Console.WriteLine("[1] Leyendo dump Source 2...");
		Source2DumpReader source2DumpReader = new Source2DumpReader();
		Source2Data source2Data = source2DumpReader.Read(file);
		Console.WriteLine($"VertexMaps: {source2Data.VertexMaps.Count}");
		Console.WriteLine($"Effects: {source2Data.Effects.Count}");
		foreach (EffectData effect in source2Data.Effects)
		{
			Console.WriteLine($"Effect: {effect.Name} Type={effect.Type}");
		}
		Console.WriteLine("\n[2] Generando Cloth Effects...");
		ClothEffectGenerator clothEffectGenerator = new ClothEffectGenerator();
		ClothEffectList clothEffectList = clothEffectGenerator.Generate(source2Data);
		Console.WriteLine($"Generated Wind: {clothEffectList.Winds.Count}");
		Console.WriteLine($"Generated Stiffen: {clothEffectList.Stiffens.Count}");
		Console.WriteLine("\n[3] Exportando VMDL...");
		VmdlExporter vmdlExporter = new VmdlExporter();
		vmdlExporter.Export(clothEffectList, "cloth_effects_vmdl.txt");
		Console.WriteLine("\nProceso terminado.");
	}
}
