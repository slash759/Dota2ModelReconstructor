using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.Versioning;

[assembly: AssemblyCompany("clothEffect")]
[assembly: AssemblyConfiguration("Debug")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyInformationalVersion("1.0.0")]
[assembly: AssemblyProduct("clothEffect")]
[assembly: AssemblyTitle("clothEffect")]
[assembly: AssemblyVersion("1.0.0.0")]
[module: RefSafetyRules(11)]
